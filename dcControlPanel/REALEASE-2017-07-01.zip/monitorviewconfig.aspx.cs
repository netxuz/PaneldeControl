﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using dcControlPanel.Conn;
using dcControlPanel.Method;
using dcControlPanel.Base;
using Telerik.Web.UI;

namespace dcControlPanel
{
  public partial class monitorviewconfig : System.Web.UI.Page
  {
    Web oWeb = new Web();
    protected void Page_Load(object sender, EventArgs e)
    {
      oWeb.ValidaSessionAdm();
      if (!IsPostBack)
      {
        CodMonitorView.Value = oWeb.GetData("CodMonitorView");
        DBConn oConn = new DBConn();
        if (oConn.Open())
        {
          cCliente oCliente = new cCliente(ref oConn);
          DataTable dtholding = oCliente.GetHolding();
          if (dtholding != null)
          {
            foreach (DataRow oRow in dtholding.Rows)
            {
              oCmbHolding.Items.Add(new ListItem(oRow["holding"].ToString(), oRow["ncodholding"].ToString()));
            }
          }
          dtholding = null;

          DataTable dtcliente = oCliente.Get();
          if (dtcliente != null)
          {
            foreach (DataRow oRow in dtcliente.Rows)
            {
              //oCmbCliente.Items.Add(new ListItem(oRow["snombre"].ToString(), oRow["nkey_cliente"].ToString()));
              oCmbCliente.Items.Add(new RadComboBoxItem(oRow["snombre"].ToString(), oRow["nkey_cliente"].ToString()));
            }
          }
          dtcliente = null;

          cAppTipoConnsulta oAppTipoConnsulta = new cAppTipoConnsulta(ref oConn);
          DataTable dtTipoConsulta = oAppTipoConnsulta.Get();

          if (dtTipoConsulta != null)
          {
            if (dtTipoConsulta.Rows.Count > 0)
            {
              oCmbTipoConsulta.Items.Add(new RadComboBoxItem("Seleccione Tipo Consulta", ""));
              foreach (DataRow oRow in dtTipoConsulta.Rows)
              {
                oCmbTipoConsulta.Items.Add(new RadComboBoxItem(oRow["nom_tipo"].ToString(), oRow["cod_tipo"].ToString()));
              }
            }
          }

          if (!string.IsNullOrEmpty(CodMonitorView.Value))
          {
            btnGrabar1.Visible = false;
            cAppMonitorView oAppMonitorView = new cAppMonitorView(ref oConn);
            oAppMonitorView.CodMonitor = CodMonitorView.Value;
            DataTable dtMonitorView = oAppMonitorView.Get();
            if (dtMonitorView != null)
            {
              if (dtMonitorView.Rows.Count > 0)
              {
                txt_nombre.Text = dtMonitorView.Rows[0]["desc_monitor_view"].ToString();
                //oCmbTipoConsulta.Items.FindByValue(dtMonitorView.Rows[0]["tipo_usuario"].ToString()).Selected = true;
                oCmbEstado.Items.FindByValue(dtMonitorView.Rows[0]["est_monitor_view"].ToString()).Selected = true;
                //oCmbCliente.Items.FindByValue(dtMonitorView.Rows[0]["cod_cliente"].ToString()).Selected = true;
              }
              dtMonitorView.Dispose();
            }
            dtMonitorView = null;

            txt_nombre.Enabled = false;
            //oCmbTipoConsulta.Enabled = false;
            oCmbEstado.Enabled = false;
            //oCmbCliente.Enabled = false;
            trPagesView.Visible = true;

            cAptMonitorPages oAptMonitorPages = new cAptMonitorPages(ref oConn);
            oAptMonitorPages.CodMonitor = CodMonitorView.Value;
            gridPages.DataSource = oAptMonitorPages.Get();
            gridPages.DataBind();

            //cAppPages oAppPages = new cAppPages(ref oConn);
            //oAppPages.CodTipo = oCmbTipoConsulta.SelectedValue.ToString();
            //DataTable oPages = oAppPages.GetByType();
            //if (oPages != null)
            //{
            //    if (oPages.Rows.Count > 0)
            //    {
            //        foreach (DataRow oRow in oPages.Rows)
            //        {
            //            oCmbPages.Items.Add(new ListItem(oRow["nom_page"].ToString(), oRow["cod_page"].ToString()));
            //        }
            //    }
            //    oPages.Dispose();
            //}
            //oPages = null;

          }

          oConn.Close();
        }
      }
    }

    protected void btnGrabar1_Click(object sender, EventArgs e)
    {
      DBConn oConn = new DBConn();
      if (oConn.Open())
      {
        cAppMonitorView oAppMonitorView = new cAppMonitorView(ref oConn);
        oAppMonitorView.CodMonitor = CodMonitorView.Value;
        oAppMonitorView.DescMonitorView = txt_nombre.Text;
        //oAppMonitorView.TipoUsuario = oCmbTipoConsulta.SelectedValue;
        oAppMonitorView.EstMonitorView = oCmbEstado.SelectedValue;
        //oAppMonitorView.CodCliente = (!string.IsNullOrEmpty(oCmbCliente.SelectedValue) ? oCmbCliente.SelectedValue : null);
        oAppMonitorView.Accion = (string.IsNullOrEmpty(CodMonitorView.Value) ? "CREAR" : "EDITAR");
        oAppMonitorView.Put();

        if (!string.IsNullOrEmpty(oAppMonitorView.Error))
        {
          Response.Write("Error : " + oAppMonitorView.Error + "<br>");
          Response.End();
        }

        CodMonitorView.Value = oAppMonitorView.CodMonitor;
        btnGrabar1.Visible = false;
        txt_nombre.Enabled = false;
        //oCmbTipoConsulta.Enabled = false;
        oCmbEstado.Enabled = false;
        //oCmbCliente.Enabled = false;
        trPagesView.Visible = true;

        //cAppPages oAppPages = new cAppPages(ref oConn);
        //oAppPages.CodTipo = oCmbTipoConsulta.SelectedValue.ToString();
        //DataTable oPages = oAppPages.GetByType();
        //if (oPages != null)
        //{
        //    if (oPages.Rows.Count > 0)
        //    {
        //        foreach (DataRow oRow in oPages.Rows)
        //        {
        //            oCmbPages.Items.Add(new ListItem(oRow["nom_page"].ToString(), oRow["cod_page"].ToString()));
        //        }
        //    }
        //    oPages.Dispose();
        //}
        //oPages = null;

        oConn.Close();
      }
    }

    protected void btnGrabar2_Click(object sender, EventArgs e)
    {
      DBConn oConn = new DBConn();
      if (oConn.Open())
      {
        cAptMonitorPages oAptMonitorPages = new cAptMonitorPages(ref oConn);
        oAptMonitorPages.CodMonitor = CodMonitorView.Value;
        DataTable dtMPage = oAptMonitorPages.Get();
        oAptMonitorPages.OrderPage = (dtMPage.Rows.Count + 1).ToString();
        dtMPage = null;
        oAptMonitorPages.CodPage = oCmbPages.SelectedValue;
        oAptMonitorPages.TimePage = txt_time.Text;
        oAptMonitorPages.EstPage = "V";
        oAptMonitorPages.TipoUsuario = oCmbTipoConsulta.SelectedValue;
        oAptMonitorPages.CodCliente = (!string.IsNullOrEmpty(oCmbCliente.SelectedValue) ? oCmbCliente.SelectedValue : null);
        oAptMonitorPages.CodHolding = (!string.IsNullOrEmpty(oCmbHolding.SelectedValue) ? oCmbHolding.SelectedValue : null);
        oAptMonitorPages.Accion = "CREAR";
        oAptMonitorPages.Put();

        if (!string.IsNullOrEmpty(oAptMonitorPages.Error))
        {
          Response.Write(oAptMonitorPages.Error);
          Response.End();
        }

        oAptMonitorPages.CodPage = string.Empty;
        oAptMonitorPages.EstPage = string.Empty;
        oAptMonitorPages.OrderPage = string.Empty;
        gridPages.DataSource = oAptMonitorPages.Get();
        gridPages.DataBind();

        oConn.Close();

      }
    }

    protected void btnVolver_Click(object sender, EventArgs e)
    {
      Response.Redirect("monitorview.aspx");
    }

    protected void oCmbTipoConsulta_OnClientSelectedIndexChanged(object o, Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs e)
    {
      oCmbPages.Items.Clear();
      DBConn oConn = new DBConn();
      if (oConn.Open())
      {
        cAppPages oAppPages = new cAppPages(ref oConn);
        oAppPages.CodTipo = oCmbTipoConsulta.SelectedValue.ToString();
        DataTable oPages = oAppPages.GetByType();
        if (oPages != null)
        {
          if (oPages.Rows.Count > 0)
          {
            foreach (DataRow oRow in oPages.Rows)
            {
              oCmbPages.Items.Add(new ListItem(oRow["nom_page"].ToString(), oRow["cod_page"].ToString()));
            }
          }
          oPages.Dispose();
        }
        oPages = null;
      }
      oConn.Close();
    }
  }
}